#include <iostream>
#include <fstream>
#include <string>
#include <stack>
#include <queue>
#include <cctype>
#include <sstream>
#include <windows.h>
#include <conio.h>
using namespace std;

const int MAX_CONTACTS = 100;
char x;
//class for attributes
class Contact {
public:
    string name;
    string phone;
    string email;
    bool isfavorite;
    bool isarchieved;
};

// Node for Doubly Linked List
class Node {
public:
    Contact data;
    Node* prev;
    Node* next;
    Node(string t_name, string t_phone, string t_email, bool isfav, bool isarch){
    	data.name = t_name;
    	data.phone = t_phone;
    	data.email = t_email;
		data.isfavorite = isfav;
		data.isarchieved = isarch;
		next = NULL;
		prev = NULL;
		}
};
//c
class Friend_group {
public:
    string groupName;
    Contact contacts[MAX_CONTACTS];
    int numContacts;
};

class ContactBook {
private:
    Node* head;
    Node* tail;

public:

    //constructor to initialize head and tail
    ContactBook()
    {
        head = NULL;
        tail = NULL;
    }
    stack<Contact> contact_stack;
    queue<Contact> contact_queue;

    void insert(string t_name, string t_phone, string t_email, bool isfav, bool isarch) {
			Node* newnode = new Node(t_name, t_phone, t_email, isfav, isarch);
			if(head ==  NULL)
			{
				head = newnode;
				tail = newnode;
				return;
			}
			else
			{
				tail->next = newnode;
				newnode->prev=tail;
				tail=newnode;
				return;
			}
		}
	

	void Update(Node* ptr){
		ptr = head;
		p:
		ofstream w("contacts.txt",ios::out);
		w.clear();
		if(!w)
		{
			w.close();
			goto p;
		}
		while(ptr != NULL) 
		{ 
			w << ptr->data.name << ",";
			w << ptr->data.phone << ",";
			w << ptr->data.email << ",";
			w << ptr->data.isfavorite << ",";
			w << ptr->data.isarchieved << ",";
			ptr = ptr->next;
		}
		w.close();
	}

	void add_contact(string t_name, string t_phone, string t_email, bool isfav, bool isarch){
        p:
		fstream w;
		w.open("contacts.txt",ios::in);
		if(!w)
		{
			w.close();
			goto p;
		}
        string VL1,VL2,VL3,V4,V5;
        bool VL4,VL5;
        ContactBook ob;
       	int n=0;
        ifstream no("count.txt");
        no >> n;
        no.close();
		for(int i=0; i<n; i=i+5)
		{
			getline(w,VL1,',');
			getline(w,VL2,',');
			getline(w,VL3,',');
			getline(w,V4,',');
			getline(w,V5,',');
			if(V4 == "1")
			{
				VL4 = 1;
			}
			else
			{
				VL4 = 0;
			}
			if(V5 == "1")
			{
				VL5 = 1;
			}
			else
			{
				VL5 = 0;
			}
			ob.insert(VL1,VL2,VL3,VL4,VL5);
		}
		ob.insert(t_name, t_phone, t_email, isfav, isarch);
		w.close();
		Node* ptr;
		ofstream no2("count.txt");
		w.clear();
        n = n + 5;
        no2 << n;
        no2.close();
		ob.Update(ptr);
	}

  void make_group() {
    Friend_group group;
    cout << "Enter group name: ";
    cin.ignore();
    getline(cin, group.groupName);

    cout << "Enter the number of contacts (up to " << MAX_CONTACTS << "): ";
    cin >> group.numContacts;
    cin.ignore(); // Ignore newline character left in the input buffer

    ofstream outFile("group.txt");
    if (!outFile) {
        cout << "Error opening file for writing.";
        return;
    }

    outFile << group.groupName << "\n";
    outFile << group.numContacts << "\n";

    for (int i = 0; i < group.numContacts; ++i) {
        cout << "Enter contact " << (i + 1) << " name: ";
        getline(cin, group.contacts[i].name);

        cout << "Enter contact " << (i + 1) << " phone: ";
        getline(cin, group.contacts[i].phone);

        outFile << group.contacts[i].name << "\n";
        outFile << group.contacts[i].phone << "\n";
    }

    outFile.close();
}

void display_group() {
    Friend_group group;
    ifstream inFile("group.txt");
    if (!inFile) {
        cout << "Error opening file for reading.";
        return;
    }

    getline(inFile, group.groupName);
    inFile >> group.numContacts;
    inFile.ignore();

    cout << "\nGroup name: " << group.groupName << "\n\n";
    cout << "Contacts:\n";
    for (int i = 0; i < group.numContacts; ++i) {
        getline(inFile, group.contacts[i].name);
        getline(inFile, group.contacts[i].phone);

        cout << "Name: " << group.contacts[i].name << "\n";
        cout << "Phone: " << group.contacts[i].phone << "\n\n";
    }

    inFile.close();
}
	void traverse(){
		head = NULL;
		tail = NULL;
		p:
			fstream w;
			w.open("contacts.txt",ios::in);
			if(!w)
			{
				w.close();
				goto p;
			}
			string VL1, VL2, VL3, V4, V5;
			bool VL4,VL5;
			ContactBook ob;
			int n=0;
	        ifstream no("count.txt");
	        no >> n;
	        no.close();
			for(int i=0; i<n; i = i+5)
			{
				getline(w,VL1,',');
				getline(w,VL2,',');
				getline(w,VL3,',');
				getline(w,V4,',');
				getline(w,V5,',');
				if(V4 == "1")
				{
					VL4 = 1;
				}
				else
				{
					VL4 = 0;
				}
				if(V5 == "1")
				{
					VL5 = 1;
				}
				else
				{
					VL5 = 0;
				}
				insert(VL1,VL2,VL3,VL4,VL5);
			}
			w.close();
	}

    void search_contacts(){
        char x;
        do {
                int choice;
                cout << "Search contacts by:" << endl;
                cout << "1. Name" << endl;
                cout << "2. Number" << endl;
                cout << "Enter your choice: ";
                cin >> choice;

                switch (choice)
                {
                case 1:
                    search_contact_by_name();
                    break;
                case 2:
                    search_contact_by_number();
                    break;
                default:
                    cout << "Invalid choice." << endl;
                    break;
                }
            
            cout << "Do you want to search more contacts? (y/n): ";
            cin >> x;
            if (tolower(x) != 'y')
            {
                cout << "Exiting......" << endl;
            }
        } while (tolower(x) == 'y');
    }
    
    void search_contact_by_name() {
    	traverse();
			Node* temp = head;
			Contact new_contact;
            while (true)
            {
                cout << "Enter contact name: ";
                cin.ignore();
                getline(cin, new_contact.name);

                bool contains_numbers = false;
                for (size_t i = 0; i < new_contact.name.length(); ++i)
                {
                    if (isdigit(new_contact.name[i]))
                    {
                        contains_numbers = true;
                        break;
                    }
                }

                if (!new_contact.name.empty() && !contains_numbers)
                {
                    break;
                }

                cout << "Invalid name. Please enter a valid name without numbers." << endl;
            }

            
            bool found = false;

            while (temp != NULL)
            {
                if (temp->data.name == new_contact.name)
                {
                    found = true;
                    break;
                }
                temp = temp->next;
            }

            if (found)
            {
                cout << "Contact found:" << endl;
                cout << "Name: " << temp->data.name << endl;
                cout << "Phone: " << temp->data.phone << endl;
                cout << "Email: " << temp->data.email << endl;
            }
            else
            {
                cout << "Contact not found." << endl;
            }
        }
    
    void search_contact_by_number() {
        traverse();
			Node* temp = head;
			Contact new_contact;
            while (true)
            {
                cout << "Enter contact phone number: ";
                cin.ignore();
                getline(cin, new_contact.phone);

                bool contains_non_digits = false;
                for (size_t i = 0; i < new_contact.phone.length(); i++)
                {
                    if (!isdigit(new_contact.phone[i]))
                    {
                        contains_non_digits = true;
                        break;
                    }
                }

                if (!new_contact.phone.empty() && !contains_non_digits)
                {
                    break;
                }

                cout << "Invalid phone number. Please enter a valid phone number containing only digits." << endl;
            }
            bool found = false;
            
            while (temp != NULL) {
                if (temp->data.phone == new_contact.phone)
                {
                    found = true;
                    break;
                }
                temp = temp->next;
            }

            if (found) {
                cout << "Contact found:" << endl;
                cout << "Name: " << temp->data.name << endl;
                cout << "Phone: " << temp->data.phone << endl;
                cout << "Email: " << temp->data.email << endl;
            }
            else {
                cout << "Contact not found." << endl;
            }
        
    }

    void update_contact()
    {
            string name;
			traverse();
            Node* temp = head;
            if(temp == NULL)
            {
            	cout<<"No Contact Stored Yet.";
            	return;
			}
			cout << "Enter the name of the contact to update: ";
            cin.ignore();
            getline(cin, name);
            bool found = false;
            while (temp != NULL)
            {
                if (temp->data.name == name)
                {
                    found = true;
                    cout << "Enter the new name: ";
                    getline(cin, temp->data.name);
                    cout << "Enter the new phone number: ";
                    getline(cin, temp->data.phone);
                    cout << "Enter the new email: ";
                    getline(cin, temp->data.email);
                    break;
                }
                temp = temp->next;
            }

            if (found)
            {
                cout << "Contact updated." << endl;

                Update(temp);
            }
            else
            {
                cout << "Contact not found." << endl;
            }
        }
    
    void sort_contacts()
    {
    	
            int choice;
            cout << "Sort contacts by:" << endl;
            cout << "1. Name" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
                sort_by_name();
                cout << "Contacts sorted by name." << endl;
                break;
            default:
                cout << "Invalid choice." << endl;
                break;
            }
    }
    void sort_by_name()
    {
        traverse();
		Node* current = head;
		int count =0;
        // Count the number of contacts in the linked list
        while (current != NULL)
        {
            current = current->next;
            count++;
        }

        // Perform bubble sort to sort contacts by name
        for (int i = 0; i < count - 1; i++)
        {
            current = head;
            Node* nextNode = current->next;

            for (int j = 0; j < count - i - 1; j++)
            {
                // Compare names and swap if necessary
                if (current->data.name > nextNode->data.name)
                {
                    Contact temp = current->data;
                    current->data = nextNode->data;
                    nextNode->data = temp;
                }

                current = nextNode;
                nextNode = nextNode->next;
            }
        }
		Update(current);
        cout << "Contacts sorted by name." << endl;
    }

    void display_contacts()
    {
        char x;
        do
        {
                int choice;
                cout << "Press 1 to display all contacts" << endl;
                cout << "Press 2 to display favorite contacts" << endl;
                cout << "Press 3 to display archived contacts" << endl;
                cout << "press 4 to display friend group contact" << endl;
                cout << "Enter your choice: ";
                cin >> choice;

                switch (choice)
                {
                case 1:
                    display_all_Contacts();
                    break;
                case 2:
                    display_favorite_contacts();
                    break;
                case 3:
                    display_archived_contacts();
                    break;
                case 4:
                    display_group();
                default:
                    cout << "Invalid choice." << endl;
                    break;
                }
            
            cout << "Do you want to display more contacts? (y/n): ";
            cin >> x;
        } while (tolower(x) == 'y');

        cout << "Exiting..." << endl;
    }
    
    void display_all_Contacts() { 
			traverse();
			Node* ptr;
			ptr = head;
			int i=0;
			while(ptr != NULL) 
			{
				cout<<"Contact #"<<i<<endl;
				cout<<"  Name: "<<ptr->data.name<<endl;
				cout<<"  Phone: "<<ptr->data.phone<<endl;
				cout<<"  Email: "<<ptr->data.email<<endl;
				cout<<endl;
				if(ptr->data.isfavorite == 1)
				{
					cout<<"     FAVOURITE CONTACT"<<endl;
				}
				if(ptr->data.isarchieved == 1)
				{
					cout<<"        ARCHIEVED"<<endl;
				}
				ptr = ptr->next; 
				i++;
		  	}
		}
    void display_favorite_contacts()
    {
        traverse();
			Node* ptr;
			ptr = head;
			int i=0;
			while(ptr != NULL) 
			{
				
				if(ptr->data.isfavorite == 1)
				{
					cout<<"Contact #"<<i<<endl;
					cout<<"  Name: "<<ptr->data.name<<endl;
					cout<<"  Phone: "<<ptr->data.phone<<endl;
					cout<<"  Email: "<<ptr->data.email<<endl;
					cout<<endl;
				}
				ptr = ptr->next; 
				i++;
		  	} 
    }

    void display_archived_contacts() {
        traverse();
			Node* ptr;
			ptr = head;
			int i=0;
			while(ptr != NULL) 
			{
				
				if(ptr->data.isarchieved == 1)
				{
					cout<<"Contact #"<<i<<endl;
					cout<<"  Name: "<<ptr->data.name<<endl;
					cout<<"  Phone: "<<ptr->data.phone<<endl;
					cout<<"  Email: "<<ptr->data.email<<endl;
					cout<<endl;
				}
				ptr = ptr->next; 
				i++;
		  	} 
    }


    void delete_favorite_contacts()
    {
         	traverse();
         	int n=0;
         	ifstream no("count.txt");
			no >> n;
	        no.close();
			ofstream no2("count.txt");
			no2.clear();
	        n = n-5;
	        no2 << n;
	        no2.close();
			Node* current;
			current = head;
			Node* previous = NULL;
			bool found;
            while (current != NULL)
            {
                if (current->data.isfavorite)
                {
                    found = true;
                    if (previous == NULL)
                    {
                        // The favorite contact is the head of the list
                        head = current->next;
                        delete current;
                        current = head;
                    }
                    else
                    {
                        previous->next = current->next;
                        delete current;
                        current = previous->next;
                    }
                    int n=0;
			        ifstream no("count.txt");
			        no >> n;
			        no.close();
			        n =  n-5;
			        ofstream no2("count.txt");
			        no2 << n;
			        no2.close();
                    Update(head);
                    
                }
                else
                {
                    previous = current;
                    current = current->next;
                }
            }

            if (found)
            {
                cout << "Favorite contacts deleted." << endl;
                Update(current);
            }
            else
            {
                cout << "No favorite contacts found." << endl;
            }
        }

    void delete_contact()
    {
    	traverse();
			Node* temp = head;
			Contact new_contact;
            while (true)
            {
                cout << "Enter contact name: ";
                cin.ignore();
                getline(cin, new_contact.name);

                bool contains_numbers = false;
                for (size_t i = 0; i < new_contact.name.length(); ++i)
                {
                    if (isdigit(new_contact.name[i]))
                    {
                        contains_numbers = true;
                        break;
                    }
                }

                if (!new_contact.name.empty() && !contains_numbers)
                {
                    break;
                }

                cout << "Invalid name. Please enter a valid name without numbers." << endl;
            }

            
            bool found = false;

            while (temp != NULL)
            {
                if (temp->data.name == new_contact.name)
                {
                    found = true;
                    break;
                }
                temp = temp->next;
            }

            if (found)
            {
                if (temp->data.name == new_contact.name)
                {
                    if (temp == head)
	                {
	                    temp = temp->next;
	                }
	                else if (temp == tail)
	                {
	                    tail = temp->prev;
	                    tail->next = NULL;
	                }
	                else
	                {
	                    temp->prev->next = temp->next;
	                    temp->next->prev = temp->prev;
	                }
	                temp = head;
	                int n=0;
			        ifstream no("count.txt");
			        no >> n;
			        no.close();
			        n =  n-5;
			        ofstream no2("count.txt");
			        no2 << n;
			        no2.close();
					Update(temp);
	                delete temp;
	                cout << "Contact deleted successfully." << endl;
					return;
                }
            }
            else
            {
                cout << "Contact not found." << endl;
            }
            getch();
        
    }
    void delete_archived_contacts()
    {
    	traverse();
        if (head == NULL)
        {
            cout << "Contact book is empty." << endl;
        }
        else
        {
            Node* current = head;
            Node* previous = NULL;
            bool found = false;

            while (current != NULL)
            {
                if (current->data.isarchieved)
                {
                    found = true;
                    if (previous == NULL)
                    {
                        head = current->next;
                        delete current;
                        current = head;
                    }
                    else
                    {
                        previous->next = current->next;
                        delete current;
                        current = previous->next;
                    }
                }
                else
                {
                    previous = current;
                    current = current->next;
                }
            }

            if (found)
            {
                cout << "Archived contacts deleted." << endl;
                int n=0;
		        ifstream no("count.txt");
		        no >> n;
		        no.close();
		        n =  n-5;
		        ofstream no2("count.txt");
		        no2 << n;
		        no2.close();
                Update(current);
            }
            else
            {
                cout << "No archived contacts found." << endl;
            }
        }
    }
    void delete_all_contacts()
    {
        if (head == NULL)
        {
            cout << "Contact book is already empty." << endl;
        }
        else
        {
            Node* temp = head;
            while (head != NULL)
            {
                temp = head;
                head = head->next;
                delete temp;
            }
            tail = NULL;
            cout << "All contacts deleted successfully." << endl;

            // Delete all contacts from file
            ofstream f4("contacts.txt");
            if (f4.is_open())
            {
                f4.clear();
                f4.close();
            }
            else
            {
                cout << "Unable to open file to delete contacts." << endl;
            }
        }
    }
};


int main()
{
    ContactBook cb;
    int choice;
    cout << "\n\t\t\t   ***Data Structures And Algorithms Project***" << endl;
    cout << "\n  Designed By:\n \t \t ~Uswa-E-Fatima      42906 \n \t \t ~Laiba Akram        42943\n" << endl;



    cout << "\t\t\t\t\t             **************\t\t" << endl;

    cout << "\t\t\t\t\t              CONTACT BOOK           " << endl;

    cout << "\t\t\t\t\t             **************\t\t\n\n" << endl;
    do {
        mainmenu:
        system("Color 57");
        cout << "\t\t\t\t      ===========================================\t\t" << endl;
        cout << "\t\t\t\t     |                 YOUR PHONE                | " << endl;
        cout << "\t\t\t\t     |    ===================================    |" << endl;

        cout << "\t\t\t\t     |    | \t~~ 1. Add contact           |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 2. Search contact        |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 3. Update contact        |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 4. Display contacts      |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 5. Grouping of contact   |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 6. Sorting               |    |" << endl;
        cout << "\t\t\t\t     |    | \t~~ 7. Delete Contacts       |    |" << endl;
        cout << "\t\t\t\t     |    | \t~  8. Exit                  |    |" << endl;
        cout << "\t\t\t\t     |    ===================================    |" << endl;
        cout << "\t\t\t\t     |                                           | " << endl;
        cout << "\t\t\t\t      ===========================================\t\t" << endl;
        cin >> choice;
        switch (choice)
        {
        case 1:
            Sleep(1000);
            system("CLS");
            char x;
	        do
	        {
	            Contact new_contact;
	            char c;
	            cin.ignore();
	
	            while (true)
	            {
	                cout << "Enter contact name: ";
	                getline(cin, new_contact.name);
	
	                bool contains_numbers = false;
	                for (size_t i = 0; i < new_contact.name.length(); ++i)
	                {
	                    if (isdigit(new_contact.name[i]))
	                    {
	                        contains_numbers = true;
	                        break;
	                    }
	                }
	
	                if (!new_contact.name.empty() && !contains_numbers)
	                {
	                    break;
	                }
	
	                cout << "Invalid name. Please enter a valid name without numbers." << endl;
	            }
	
	            while (true)
	            {
	                cout << "Enter contact phone number: ";
	                getline(cin, new_contact.phone);
	
	                bool contains_non_digits = false;
	                for (size_t i = 0; i < new_contact.phone.length(); i++)
	                {
	                    if (!isdigit(new_contact.phone[i]))
	                    {
	                        contains_non_digits = true;
	                        break;
	                    }
	                }
	
	                if (!new_contact.phone.empty() && !contains_non_digits)
	                {
	                    break;
	                }
	
	                cout << "Invalid phone number. Please enter a valid phone number containing only digits." << endl;
	            }
	
	            cout << "Enter contact email: ";
	            getline(cin, new_contact.email);
	
	            // Prompt for favorite status
	            cout << "Is this contact a favorite? (y/n): ";
	            cin >> c;
	            new_contact.isfavorite = (tolower(c) == 'y');
	
	            // Prompt for archiving status
	            cout << "Do you want to archive this contact? (y/n): ";
	            cin >> c;
	            new_contact.isarchieved = (tolower(c) == 'y');
	
	            cout << "Contact added successfully." << endl;
	            cb.add_contact(new_contact.name, new_contact.phone, new_contact.email, new_contact.isfavorite, new_contact.isarchieved);
	            cout << "Do you want to add more contacts? (y/n): ";
	            cin >> x;
	        } while (tolower(x) == 'y');
            
            system("CLS");
            goto mainmenu;
        case 2:
            Sleep(1000);
            system("CLS");
            cb.search_contacts();
            system("CLS");
            goto mainmenu;
        case 3:
            Sleep(1000);
            system("CLS");
            cb.update_contact();
            system("CLS");
            goto mainmenu;
        case 4:
            Sleep(1000);
            system("CLS");
            cb.display_contacts();
            system("CLS");
            goto mainmenu;
        case 5:
            Sleep(1000);
            system("CLS");
            cb.make_group();
            system("CLS");
            goto mainmenu;
        case 6:
            Sleep(1000);
            system("CLS");
            cb.sort_contacts();
            system("CLS");
            goto mainmenu;
        case 7:
            Sleep(1000);
            system("CLS");
            cb.delete_contact();
            system("CLS");
            goto mainmenu;
        case 8:
            Sleep(1000);
            system("CLS");
            cout << "Exiting..." << endl;
            exit(0);
        default:
            cout << "Invalid choice." << endl;
            break;
        }
    } while (true);

    return 0;
}
